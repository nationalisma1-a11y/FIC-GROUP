# FIC GROUP SONGON — Images pour v0 (Version V2)

Ce dossier contient **toutes les images réelles** à utiliser dans le site FIC GROUP.

Structure attendue par le prompt v0 :

```
/public/images/realisations/
```

---

## 1. Images PRINCIPALES (obligatoires selon le prompt)

| Fichier | Service / Badge | Titre affiché | Description |
|---------|------------------|---------------|-------------|
| `bulldozer-cat.jpg` | **Foncier** | Décapage de terrain | Engin CAT (chargeuse) en action sur terrain rouge à Songon |
| `bien-duplex.jpg` | **Immobilier** | Bien immobilier — portefeuille FIC GROUP | Villa moderne contemporaine (rendu / bien du portefeuille) |
| `bornage-topo.jpg` | **Foncier** | Bornage & levé topographique | Géomètres en intervention (théodolite + jalon) |
| `construction-btcs.jpg` | **BTP** | Construction BTCS & maçonnerie | Immeuble en construction (briques + enduit blanc) |
| `maintenance-clim.jpg` | **Climatisation** | Maintenance climatisation | ⚠️ **IMAGE MANQUANTE** — à fournir par le client |

---

## 2. Images supplémentaires pour la GALERIE

Ces images enrichissent la section « Réalisations & savoir-faire ».

| Fichier | Service représenté | Description |
|---------|--------------------|-------------|
| `villa-moderne-fence.jpg` | Immobilier / BTP | Villa contemporaine blanche avec clôture, chantier en cours |
| `villa-construction-1.jpg` | BTP | Villa moderne en phase de construction (gros œuvre) |
| `villas-modernes-groupe.jpg` | Immobilier | Ensemble de villas contemporaines (projet terminé / avancé) |
| `villa-balcon-verre.jpg` | Immobilier / BTP | Villa à balcons vitrés, finitions en cours |
| `residence-fermee.jpg` | Immobilier | Résidence sécurisée avec portail (projet livré) |
| `lotissement-moderne.jpg` | Immobilier / BTP | Rangée de maisons contemporaines (lotissement) |
| `finition-maison.jpg` | BTP | Maison en phase de finition (escalier, bardage bois) |
| `chantier-villas-rangee.jpg` | BTP | Chantier de villas en rangée (second œuvre) |
| `travaux-voirie-engins.jpg` | Foncier | Travaux de voirie / décapage avec engins (niveleuses + excavateurs) |

---

## 3. Mapping exact pour le code v0

Dans la section Réalisations, utiliser **en priorité** :

```tsx
const realisations = [
  {
    src: "/images/realisations/bulldozer-cat.jpg",
    title: "Décapage de terrain",
    badge: "Foncier",
    alt: "Bulldozer CAT utilisé pour le décapage d'un terrain à Songon"
  },
  {
    src: "/images/realisations/bien-duplex.jpg",
    title: "Bien immobilier — portefeuille FIC GROUP",
    badge: "Immobilier",
    alt: "Bien immobilier du portefeuille FIC GROUP"
  },
  {
    src: "/images/realisations/bornage-topo.jpg",
    title: "Bornage & levé topographique",
    badge: "Foncier",
    alt: "Opération de bornage et levé topographique"
  },
  {
    src: "/images/realisations/construction-btcs.jpg",
    title: "Construction BTCS & maçonnerie",
    badge: "BTP",
    alt: "Travaux de construction BTCS et maçonnerie"
  },
  // maintenance-clim.jpg à ajouter dès que disponible
];
```

---

## 4. Note importante

- **Aucune image de stock** n’a été conservée.
- Toutes les photos sont des **réalisations réelles** liées aux activités de FIC GROUP à Songon / Abidjan.
- L’image `maintenance-clim.jpg` est absente du lot fourni. Elle devra être ajoutée manuellement par le client pour le pôle Climatisation.

---

## 5. Comment uploader dans v0

1. Téléchargez le fichier ZIP `fic-group-images-v0.zip`
2. Dans v0, uploadez le ZIP **ou** les images individuellement dans le projet.
3. Placez-les dans `/public/images/realisations/` (v0 gère généralement le dossier public automatiquement).
4. Utilisez les noms de fichiers **exactement** comme indiqués ci-dessus.

---

**FIC GROUP SONGON**  
Abidjan, Songon, Carrefour Diapoté  
WhatsApp : +225 07 03 53 03 43  
Email : ficgroup25@gmail.com
